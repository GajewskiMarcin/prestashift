<?php
/**
 * PrestaShift Migration Module
 *
 * @author    marcingajewski.pl <kontakt@marcingajewski.pl>
 * @copyright 2026 marcingajewski.pl
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * @attribution PrestaShift by Marcin Gajewski (marcingajewski.pl). Keep the Attribution Notice in prestashift.php — AFL-3.0 section 6.
 * @version   1.0.0
 */
namespace PrestaShift\Service;

use PDO;
use Exception;

class DirectDbClient
{
    private $pdo;
    private $prefix;
    private $source_url;

    public function __construct($host, $port, $dbname, $user, $pass, $prefix, $source_url = '')
    {
        $dsn = "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4";
        $this->pdo = new PDO($dsn, $user, $pass);
        $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $this->prefix = $prefix;
        $this->source_url = rtrim($source_url, '/');
    }

    /**
     * Execute SQL query and return ConnectorResult
     */
    public function query($sql)
    {
        $stmt = $this->pdo->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return new ConnectorResult($data);
    }

    /**
     * Test connection and detect PrestaShop version
     */
    public function test()
    {
        try {
            $stmt = $this->pdo->query("SELECT VERSION() as v");
            $row = $stmt->fetch(PDO::FETCH_ASSOC);

            $psVersion = null;
            $tbVersion = '';
            try {
                $stmt2 = $this->pdo->query(
                    "SELECT value FROM {$this->prefix}configuration WHERE name = 'PS_VERSION_DB' LIMIT 1"
                );
                $row2 = $stmt2->fetch(PDO::FETCH_ASSOC);
                if ($row2) {
                    $psVersion = $row2['value'];
                }

                // thirtybees keeps its own version there: its "1.7.0" is not
                // PrestaShop 1.7. For the data it is a PrestaShop 1.6.1, the
                // version it reports to modules.
                $stmt3 = $this->pdo->query(
                    "SELECT COUNT(*) FROM {$this->prefix}configuration WHERE name LIKE 'TB\\_PAGE\\_CACHE\\_%'"
                );
                if ((int)$stmt3->fetchColumn() > 0) {
                    $tbVersion = (string)$psVersion;
                    $psVersion = '1.6.1.999';
                }
            } catch (Exception $e) {
                // table may not exist — ignore
            }

            return [
                'success'    => true,
                'ps_version' => $psVersion,
                'tb_version' => $tbVersion,
                'prefix'     => $this->prefix,
            ];
        } catch (Exception $e) {
            return [
                'success' => false,
                'error'   => $e->getMessage(),
            ];
        }
    }

    /**
     * Fetch file from source shop via HTTP
     */
    public function getFile($path)
    {
        try {
            if ($this->source_url) {
                return @file_get_contents($this->source_url . '/' . ltrim($path, '/'));
            }
            return false;
        } catch (Exception $e) {
            return false;
        }
    }
}
