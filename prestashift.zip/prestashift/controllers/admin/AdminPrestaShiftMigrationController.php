<?php
/**
 * PrestaShift Migration Module
 * 
 * @author    marcingajewski.pl <kontakt@marcingajewski.pl>
 * @copyright 2026 marcingajewski.pl
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * @attribution PrestaShift by Marcin Gajewski (marcingajewski.pl). Keep the Attribution Notice in prestashift.php — AFL-3.0 section 6.
 * @version   1.0.0
 */

class AdminPrestaShiftMigrationController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function initContent()
    {
        parent::initContent();

        $this->context->smarty->assign([
            'ps_version' => _PS_VERSION_,
            'module_dir' => $this->module->getPathUri(),
            'controller_url' => $this->context->link->getAdminLink('AdminPrestaShiftMigration'),
            'ps_translations' => [
                'loading' => $this->module->l('Loading...', 'AdminPrestaShiftMigrationController'),
                'error' => $this->module->l('Error', 'AdminPrestaShiftMigrationController'),
                'success' => $this->module->l('Success', 'AdminPrestaShiftMigrationController'),
                'connection_failed' => $this->module->l('Connection failed:', 'AdminPrestaShiftMigrationController'),
                'communication_error' => $this->module->l('Communication error:', 'AdminPrestaShiftMigrationController'),
                'migration_completed' => $this->module->l('Migration fully completed!', 'AdminPrestaShiftMigrationController'),
                'done' => $this->module->l('Done!', 'AdminPrestaShiftMigrationController'),
                'waiting' => $this->module->l('Waiting', 'AdminPrestaShiftMigrationController'),
                'resuming' => $this->module->l('Resuming migration from task:', 'AdminPrestaShiftMigrationController'),
                'detected_interrupted' => $this->module->l('Interrupted migration detected. Task:', 'AdminPrestaShiftMigrationController'),
                'offset' => $this->module->l(', Offset:', 'AdminPrestaShiftMigrationController'),
                'resume_button' => $this->module->l('Resume work from this point', 'AdminPrestaShiftMigrationController'),
                'reset_session' => $this->module->l('Reset / Start New', 'AdminPrestaShiftMigrationController'),
                'st_old_status' => $this->module->l('Old Status (Source)', 'AdminPrestaShiftMigrationController'),
                'st_new_status' => $this->module->l('New Status (Target)', 'AdminPrestaShiftMigrationController'),
                'st_error_fetch' => $this->module->l('Error while fetching statuses from source.', 'AdminPrestaShiftMigrationController'),
                'loading_statuses' => $this->module->l('Loading source statuses...', 'AdminPrestaShiftMigrationController'),
                'none_selected' => $this->module->l('None selected', 'AdminPrestaShiftMigrationController'),
                'yes_clean' => $this->module->l('Yes (Clean Install)', 'AdminPrestaShiftMigrationController'),
                'no' => $this->module->l('No', 'AdminPrestaShiftMigrationController'),
                'batch' => $this->module->l('Batch:', 'AdminPrestaShiftMigrationController'),
                'delay' => $this->module->l('Delay:', 'AdminPrestaShiftMigrationController'),
                'none' => $this->module->l('None', 'AdminPrestaShiftMigrationController'),
                'images' => $this->module->l('Images:', 'AdminPrestaShiftMigrationController'),
                'unknown' => $this->module->l('Unknown', 'AdminPrestaShiftMigrationController'),
                // Strings previously hardcoded in admin.js
                'fill_all_fields' => $this->module->l('Please fill in all fields', 'AdminPrestaShiftMigrationController'),
                'fill_db_fields' => $this->module->l('Please fill in host, database name, and user', 'AdminPrestaShiftMigrationController'),
                'test_connection_btn' => $this->module->l('Test Connection & Continue', 'AdminPrestaShiftMigrationController'),
                'testing' => $this->module->l('Testing...', 'AdminPrestaShiftMigrationController'),
                'rate_limit_wait' => $this->module->l('Rate limit reached — waiting before retrying the batch...', 'AdminPrestaShiftMigrationController'),
                // Why a step could not be loaded — a bare "failed" tells nobody anything
                'step_failed' => $this->module->l('This step could not be loaded.', 'AdminPrestaShiftMigrationController'),
                'err_no_answer' => $this->module->l('The shop gave no answer — the request was blocked, timed out, or the connection dropped.', 'AdminPrestaShiftMigrationController'),
                'err_session' => $this->module->l('Your back-office session has expired. Reload the page and log in again.', 'AdminPrestaShiftMigrationController'),
                'err_not_found' => $this->module->l('The module page was not found. Reinstall the module or clear the shop cache.', 'AdminPrestaShiftMigrationController'),
                'err_server' => $this->module->l('The shop returned a server error. The details are below and in your hosting error log.', 'AdminPrestaShiftMigrationController'),
                'err_not_json' => $this->module->l('The shop returned something else than the module expected — usually a PHP warning, a security plugin or a login page.', 'AdminPrestaShiftMigrationController'),
                'zones_error' => $this->module->l('Zones could not be loaded from the source shop.', 'AdminPrestaShiftMigrationController'),
                'statuses_error' => $this->module->l('Order statuses could not be loaded from the source shop.', 'AdminPrestaShiftMigrationController'),
                'connection_error' => $this->module->l('Connection Error', 'AdminPrestaShiftMigrationController'),
                'connection_check_failed' => $this->module->l('Connection Check Failed:', 'AdminPrestaShiftMigrationController'),
                'preflight_running' => $this->module->l('Running pre-flight checks...', 'AdminPrestaShiftMigrationController'),
                'starting_migration' => $this->module->l('Starting migration...', 'AdminPrestaShiftMigrationController'),
                'migration_paused' => $this->module->l('Migration paused by user.', 'AdminPrestaShiftMigrationController'),
                'transfer_complete' => $this->module->l('Data transfer complete. Running post-migration tasks...', 'AdminPrestaShiftMigrationController'),
                'post_tasks_running' => $this->module->l('Running post-migration tasks...', 'AdminPrestaShiftMigrationController'),
                'post_tasks_failed' => $this->module->l('Post-migration tasks failed — please clear cache manually.', 'AdminPrestaShiftMigrationController'),
                'error_prefix' => $this->module->l('Error: ', 'AdminPrestaShiftMigrationController'),
                'network_error' => $this->module->l('Communication Error (Network/Timeout). Click Resume to retry this batch.', 'AdminPrestaShiftMigrationController'),
                'confirm_clear_session' => $this->module->l('Are you sure you want to clear the saved session?', 'AdminPrestaShiftMigrationController'),
                // Entity labels used in preview and report tables
                'lbl_products' => $this->module->l('Products', 'AdminPrestaShiftMigrationController'),
                'lbl_categories' => $this->module->l('Categories', 'AdminPrestaShiftMigrationController'),
                'lbl_customers' => $this->module->l('Customers', 'AdminPrestaShiftMigrationController'),
                'lbl_orders' => $this->module->l('Orders', 'AdminPrestaShiftMigrationController'),
                'lbl_manufacturers' => $this->module->l('Manufacturers', 'AdminPrestaShiftMigrationController'),
                'lbl_carriers' => $this->module->l('Carriers', 'AdminPrestaShiftMigrationController'),
                'lbl_cms_pages' => $this->module->l('CMS Pages', 'AdminPrestaShiftMigrationController'),
                'lbl_images' => $this->module->l('Images', 'AdminPrestaShiftMigrationController'),
                'lbl_cart_rules' => $this->module->l('Cart Rules', 'AdminPrestaShiftMigrationController'),
                'lbl_reviews' => $this->module->l('Product Reviews', 'AdminPrestaShiftMigrationController'),
                // Task identifiers for JS
                'customers' => $this->module->l('customers', 'AdminPrestaShiftMigrationController'),
                'addresses' => $this->module->l('addresses', 'AdminPrestaShiftMigrationController'),
                'categories' => $this->module->l('categories', 'AdminPrestaShiftMigrationController'),
                'tax_rules' => $this->module->l('tax rules', 'AdminPrestaShiftMigrationController'),
                'localization' => $this->module->l('localization', 'AdminPrestaShiftMigrationController'),
                'attribute_groups' => $this->module->l('attribute groups', 'AdminPrestaShiftMigrationController'),
                'attributes' => $this->module->l('attributes', 'AdminPrestaShiftMigrationController'),
                'products' => $this->module->l('products', 'AdminPrestaShiftMigrationController'),
                'product_attributes' => $this->module->l('combinations', 'AdminPrestaShiftMigrationController'),
                'specific_prices' => $this->module->l('discounts', 'AdminPrestaShiftMigrationController'),
                'manufacturers' => $this->module->l('manufacturers', 'AdminPrestaShiftMigrationController'),
                'suppliers' => $this->module->l('suppliers', 'AdminPrestaShiftMigrationController'),
                'features' => $this->module->l('features', 'AdminPrestaShiftMigrationController'),
                'feature_values' => $this->module->l('feature values', 'AdminPrestaShiftMigrationController'),
                'feature_products' => $this->module->l('feature assignment', 'AdminPrestaShiftMigrationController'),
                'attachments' => $this->module->l('attachments', 'AdminPrestaShiftMigrationController'),
                'cms' => $this->module->l('cms content', 'AdminPrestaShiftMigrationController'),
                'images' => $this->module->l('images', 'AdminPrestaShiftMigrationController'),
                'employees' => $this->module->l('employees', 'AdminPrestaShiftMigrationController'),
                'cart_rules' => $this->module->l('vouchers', 'AdminPrestaShiftMigrationController'),
                'messages' => $this->module->l('customer messages', 'AdminPrestaShiftMigrationController'),
                'carriers' => $this->module->l('carriers', 'AdminPrestaShiftMigrationController'),
                'orders' => $this->module->l('orders', 'AdminPrestaShiftMigrationController'),
            ]
        ]);

        $this->setTemplate('configure.tpl');
    }

    public function setMedia($isNewTheme = false)
    {
        parent::setMedia($isNewTheme);
        $time = time(); // Force cache bust
        $this->addCSS($this->module->getPathUri() . 'views/css/admin.css?v=' . $time);
        $this->addJS($this->module->getPathUri() . 'views/js/admin.js?v=' . $time);
    }

    public function ajaxProcessrenderStep()
    {
        ob_start(); // Start buffering to capture any stray output
        
        $step = (int) Tools::getValue('step');
        $content = '';
        
        // Simplified debugging (kept for safety)

        try {
            if (!defined('_PS_MODULE_DIR_')) {
                throw new Exception('_PS_MODULE_DIR_ is not defined');
            }
            
            $moduleDir = _PS_MODULE_DIR_;
            // The real folder, not a hardcoded name — the module still works
            // when its directory was renamed on upload.
            $basePath = $moduleDir . $this->module->name . '/views/templates/admin/_steps/';
            
            $debug_info = [
                'step' => $step,
                'module_dir_const' => $moduleDir,
                'basePath' => $basePath
            ];
            
            // Log path info
            PrestaShopLogger::addLog("[PrestaShift] BasePath: $basePath", 1, null, 'PrestaShift', 1, true);

            switch ($step) {
                case 1: $tpl = $basePath . 'connection.tpl'; break;
                case 2: $tpl = $basePath . 'scope.tpl'; break;
                case 3: $tpl = $basePath . 'options.tpl'; break;
                case 4: $tpl = $basePath . 'migration.tpl'; break;
                default: $tpl = null;
            }
            
            $debug_info['tpl_path'] = $tpl;
            $debug_info['exists'] = ($tpl && file_exists($tpl));

            if ($tpl && file_exists($tpl)) {
                try {
                     $this->context->smarty->assign([
                         'controller_url' => $this->context->link->getAdminLink('AdminPrestaShiftMigration'),
                         'module_dir' => $this->module->getPathUri(),
                     ]);
                     $content = $this->context->smarty->fetch($tpl);
                } catch (Throwable $e) {
                     $content = "<!-- LOAD FAILED: " . $e->getMessage() . " -->"; 
                     $content .= @file_get_contents($tpl);
                     $debug_info['smarty_error'] = $e->getMessage();
                }
            } else {
                $content = '<div class="alert alert-danger">Template not found at: ' . $tpl . '</div>';
            }
            
        } catch (Throwable $e) {
            $debug_info['error'] = $e->getMessage();
            $content = '<div class="alert alert-danger">Fatal Error: ' . $e->getMessage() . '</div>';
            PrestaShopLogger::addLog("[PrestaShift] Fatal: " . $e->getMessage(), 3, null, 'PrestaShift', 1, true);
        }

        $response = [
            'content' => $content,
            'debug' => $debug_info, 
            'version' => 'FINAL_CHECK_V2'
        ];
        
        $json = json_encode($response);
        if ($json === false) {
             $json = json_encode(['content' => 'JSON Encode Error: ' . json_last_error_msg()]);
        }
        
        $json = json_encode($response);
        if ($json === false) {
             $json = json_encode(['content' => 'JSON Encode Error: ' . json_last_error_msg()]);
        }
        
        PrestaShopLogger::addLog("[PrestaShift] Response: $json", 1, null, 'PrestaShift', 1, true);
        
        ob_end_clean(); // Discard any warnings/text caught in buffer
        header('Content-Type: application/json');
        die($json);
    }

    public function ajaxProcesscheckConnection()
    {
        ob_start();
        $method = Tools::getValue('connection_method', 'bridge');

        try {
            if ($method === 'direct') {
                $config = [
                    'connection_method' => 'direct',
                    'db_host' => Tools::getValue('db_host', 'localhost'),
                    'db_port' => (int)Tools::getValue('db_port', 3306),
                    'db_name' => Tools::getValue('db_name'),
                    'db_user' => Tools::getValue('db_user'),
                    'db_pass' => Tools::getValue('db_pass', ''),
                    'db_prefix' => Tools::getValue('db_prefix', 'ps_'),
                    'source_url' => \PrestaShift\Service\ConnectorClient::shopUrl(Tools::getValue('source_url', '')),
                ];
            } else {
                $sourceUrl = \PrestaShift\Service\ConnectorClient::shopUrl(Tools::getValue('source_url'));
                $config = [
                    'connection_method' => 'bridge',
                    'use_bridge' => 1,
                    'bridge_url' => $sourceUrl . '/modules/psconnector/api.php',
                    'bridge_token' => Tools::getValue('bridge_token'),
                    'db_prefix' => Tools::getValue('db_prefix', 'ps_'),
                    'source_url' => $sourceUrl,
                ];
            }

            $manager = new \PrestaShift\Service\MigrationManager();
            $conn = $manager->getConnection($config);

            $test = $conn->test();
            if (!$test['success']) {
                throw new \Exception("Connection test failed: " . ($test['error'] ?? 'Unknown error'));
            }
            $prefix = $test['prefix'] ?? $config['db_prefix'];
            $sourceVersion = $test['ps_version'] ?? 'unknown';

            // How many shops the source holds. A multistore source migrates as
            // one shop: every per-shop table is read ordered by id_shop and the
            // first row wins, so the lowest-numbered shop is the one that moves.
            // That is a reasonable default and a terrible surprise, so it is
            // said out loud here instead of being discovered from the prices.
            $sourceShops = [];
            try {
                $rows = $conn->query('SELECT `id_shop`, `name` FROM `' . $prefix . 'shop` ORDER BY `id_shop` ASC')
                    ->fetchAll(\PDO::FETCH_ASSOC);
                foreach ((array) $rows as $row) {
                    $sourceShops[(int) $row['id_shop']] = (string) $row['name'];
                }
            } catch (\Throwable $e) {
                // single-shop installations before 1.5 have no shop table
            }

            // Remembered for the error reports: knowing the source shop's
            // PrestaShop, PHP and connector versions saves a round of questions.
            \Configuration::updateValue('PRESTASHIFT_SOURCE_INFO', json_encode([
                'ps_version' => $sourceVersion,
                'php_version' => $test['php_version'] ?? 'unknown',
                'version' => $test['version'] ?? 'unknown',
                'prefix' => $prefix,
                'shops' => count($sourceShops),
            ]));
            $targetVersion = _PS_VERSION_;

            $warnings = $this->getVersionWarnings($sourceVersion, $targetVersion);

            if (count($sourceShops) > 1) {
                $firstId = (int) array_key_first($sourceShops);
                $warnings[] = sprintf(
                    $this->module->l('The source is a multistore installation with %1$d shops. Only the data of shop "%2$s" (id %3$d) will be migrated — the other shops are ignored.', 'AdminPrestaShiftMigrationController'),
                    count($sourceShops),
                    $sourceShops[$firstId],
                    $firstId
                );
            }

            $methodLabel = ($method === 'direct') ? 'Direct DB' : 'Bridge';
            $response = [
                'success' => true,
                'message' => $methodLabel . ' ' . $this->module->l('connected! Prefix detected:', 'AdminPrestaShiftMigrationController') . ' ' . $prefix,
                'source_version' => $sourceVersion,
                'target_version' => $targetVersion,
                'warnings' => $warnings,
            ];

        } catch (\Throwable $e) {
            $response = ['success' => false, 'message' => $this->module->l('Connection failed:', 'AdminPrestaShiftMigrationController') . ' ' . $e->getMessage()];
        }

        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }
    
    /**
     * Generate warnings based on source/target version difference
     */
    private function getVersionWarnings($sourceVersion, $targetVersion)
    {
        $warnings = [];
        $srcMajor = (int)$sourceVersion;
        $tgtMajor = (int)$targetVersion;

        // PS 1.7 → 8 or 9
        if ($srcMajor === 1 && $tgtMajor >= 8) {
            $warnings[] = $this->module->l('redirect_type values will be auto-converted (301→301-product, 302→302-product).', 'AdminPrestaShiftMigrationController');
            $warnings[] = $this->module->l('Column id_product_redirected renamed to id_type_redirected — handled automatically.', 'AdminPrestaShiftMigrationController');
        }

        // PS 1.7 or 8 → 9
        if ($tgtMajor >= 9) {
            $warnings[] = $this->module->l('PrestaShop 9 uses Symfony 6.4 — some hooks were removed. Module configurations may need manual adjustment.', 'AdminPrestaShiftMigrationController');
        }

        // Same major version
        if ($srcMajor === $tgtMajor) {
            $warnings[] = $this->module->l('Same major version detected — minimal compatibility issues expected.', 'AdminPrestaShiftMigrationController');
        }

        // Downgrade warning
        if (version_compare($sourceVersion, $targetVersion, '>')) {
            $warnings[] = $this->module->l('WARNING: Source version is newer than target. Downgrade migration may cause data loss.', 'AdminPrestaShiftMigrationController');
        }

        return $warnings;
    }

    private function logProbe($msg) {
        $timestamp = date('H:i:s');
        error_log("[PrestaShift Probe $timestamp] $msg");
        // Optional: PrestaShopLogger::addLog("[PrestaShift Probe] $msg", 1);
    }

    /**
     * Pre-flight check before migration start
     */
    public function ajaxProcesspreFlight()
    {
        ob_start();
        $checks = [];

        // 1. PHP memory_limit
        $memoryLimit = ini_get('memory_limit');
        $memoryBytes = $this->convertToBytes($memoryLimit);
        $checks[] = [
            'label' => 'PHP memory_limit',
            'value' => $memoryLimit,
            'ok' => $memoryBytes >= 128 * 1024 * 1024,
            'hint' => $memoryBytes < 128 * 1024 * 1024 ? $this->module->l('Recommended: 256M or higher', 'AdminPrestaShiftMigrationController') : '',
        ];

        // 2. max_execution_time
        $maxExec = (int)ini_get('max_execution_time');
        $checks[] = [
            'label' => 'max_execution_time',
            'value' => $maxExec . 's',
            'ok' => $maxExec === 0 || $maxExec >= 30,
            'hint' => ($maxExec > 0 && $maxExec < 30) ? $this->module->l('Recommended: 60s or higher', 'AdminPrestaShiftMigrationController') : '',
        ];

        // 3. Disk free space
        $freeSpace = @disk_free_space(_PS_ROOT_DIR_);
        $checks[] = [
            'label' => $this->module->l('Free disk space', 'AdminPrestaShiftMigrationController'),
            'value' => $freeSpace ? round($freeSpace / 1024 / 1024) . ' MB' : 'unknown',
            'ok' => $freeSpace === false || $freeSpace > 500 * 1024 * 1024,
            'hint' => ($freeSpace && $freeSpace <= 500 * 1024 * 1024) ? $this->module->l('Low disk space — image transfer may fail', 'AdminPrestaShiftMigrationController') : '',
        ];

        // 4. cURL available
        $checks[] = [
            'label' => 'cURL',
            'value' => function_exists('curl_init') ? 'OK' : 'Missing',
            'ok' => function_exists('curl_init'),
            'hint' => !function_exists('curl_init') ? $this->module->l('cURL is required for bridge connection', 'AdminPrestaShiftMigrationController') : '',
        ];

        // 5. Target product count (is shop clean?)
        $productCount = (int)Db::getInstance()->getValue("SELECT COUNT(*) FROM `" . _DB_PREFIX_ . "product`");
        $checks[] = [
            'label' => $this->module->l('Existing products in target', 'AdminPrestaShiftMigrationController'),
            'value' => $productCount,
            'ok' => true,
            'hint' => $productCount > 0 ? $this->module->l('Existing data is kept — migrated records get new IDs. Enable "Clean Target Data" to keep the source IDs 1:1.', 'AdminPrestaShiftMigrationController') : '',
        ];

        $allOk = true;
        foreach ($checks as $c) {
            if (!$c['ok']) { $allOk = false; break; }
        }

        $response = ['success' => true, 'checks' => $checks, 'all_ok' => $allOk];

        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }

    /**
     * Dry-run preview — count records from source
     */
    public function ajaxProcesspreview()
    {
        ob_start();
        try {
            $method = Tools::getValue('connection_method', 'bridge');
            $config = [
                'connection_method' => $method,
                'db_prefix' => Tools::getValue('db_prefix', 'ps_'),
                'source_url' => \PrestaShift\Service\ConnectorClient::shopUrl(Tools::getValue('source_url', '')),
            ];
            if ($method === 'direct') {
                $config['db_host'] = Tools::getValue('db_host', 'localhost');
                $config['db_port'] = (int)Tools::getValue('db_port', 3306);
                $config['db_name'] = Tools::getValue('db_name');
                $config['db_user'] = Tools::getValue('db_user');
                $config['db_pass'] = Tools::getValue('db_pass', '');
            } else {
                $config['bridge_token'] = Tools::getValue('bridge_token');
            }

            $manager = new \PrestaShift\Service\MigrationManager();
            $conn = $manager->getConnection($config);
            $prefix = $config['db_prefix'];

            $counts = [];
            $queries = [
                'products'      => "SELECT COUNT(*) as c FROM `{$prefix}product`",
                'categories'    => "SELECT COUNT(*) as c FROM `{$prefix}category` WHERE id_category > 2",
                'customers'     => "SELECT COUNT(*) as c FROM `{$prefix}customer`",
                'orders'        => "SELECT COUNT(*) as c FROM `{$prefix}orders`",
                'manufacturers' => "SELECT COUNT(*) as c FROM `{$prefix}manufacturer`",
                'carriers'      => "SELECT COUNT(*) as c FROM `{$prefix}carrier`",
                'cms'           => "SELECT COUNT(*) as c FROM `{$prefix}cms`",
                'images'        => "SELECT COUNT(*) as c FROM `{$prefix}image`",
                'cart_rules'    => "SELECT COUNT(*) as c FROM `{$prefix}cart_rule`",
                'reviews'       => "SELECT COUNT(*) as c FROM `{$prefix}product_comment`",
            ];

            foreach ($queries as $key => $sql) {
                try {
                    $row = $conn->query($sql)->fetchAll(\PDO::FETCH_ASSOC);
                    $counts[$key] = (int)($row[0]['c'] ?? 0);
                } catch (\Throwable $e) {
                    $counts[$key] = 0;
                }
            }

            $response = ['success' => true, 'counts' => $counts];
        } catch (\Throwable $e) {
            $response = ['success' => false, 'message' => $e->getMessage()];
        }

        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }

    private function convertToBytes($val)
    {
        $val = trim($val);
        $last = strtolower($val[strlen($val) - 1]);
        $num = (int)$val;
        switch ($last) {
            case 'g': $num *= 1024;
            case 'm': $num *= 1024;
            case 'k': $num *= 1024;
        }
        return $num;
    }

    public function ajaxProcessstartMigration()
    {
        // NUCLEAR DEBUGGING for Batch
        register_shutdown_function(function() {
            $error = error_get_last();
            if ($error && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR)) {
                http_response_code(500);
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'FATAL BATCH ERROR: ' . $error['message'] . ' in ' . $error['file'] . ':' . $error['line']]);
                die();
            }
        });

        ob_start();

        $method = Tools::getValue('connection_method', 'bridge');
        $config = [
            'connection_method' => $method,
            'db_prefix' => Tools::getValue('db_prefix', 'ps_'),
            'source_url' => \PrestaShift\Service\ConnectorClient::shopUrl(Tools::getValue('source_url', '')),
            'scope' => Tools::getValue('scope', []),
            'options' => Tools::getValue('options', [])
        ];

        // Add method-specific config
        if ($method === 'direct') {
            $config['db_host'] = Tools::getValue('db_host', 'localhost');
            $config['db_port'] = (int)Tools::getValue('db_port', 3306);
            $config['db_name'] = Tools::getValue('db_name');
            $config['db_user'] = Tools::getValue('db_user');
            $config['db_pass'] = Tools::getValue('db_pass', '');
        } else {
            $config['use_bridge'] = 1;
            $config['bridge_token'] = Tools::getValue('bridge_token');
        }

        // Status mapping is sent as separate POST field, merge into options
        $statusMap = Tools::getValue('status_map', []);
        if (!empty($statusMap)) {
            $config['options']['status_map'] = $statusMap;
        }

        // Zone mapping for carrier migration
        $zoneMap = Tools::getValue('zone_map', []);
        if (!empty($zoneMap)) {
            $config['options']['zone_map'] = $zoneMap;
        }

        try {
            // 2. Id map. Every migrated record gets its target id from the
            // persisted map: source id + a per-entity offset fixed at the first
            // migration (the target's MAX id then), reused by later runs.
            \PrestaShift\Service\IdMapper::ensureTables();

            $manager = new \PrestaShift\Service\MigrationManager();
            $sourceConn = $manager->getConnection($config);
            $config['id_source'] = \PrestaShift\Service\IdMapper::fingerprint(
                $sourceConn,
                $config['db_prefix'],
                $config['source_url']
            );

            // 3. Cleanup if requested. Emptied tables also lose their map
            // entries, so their offsets restart at 0 and ids come out 1:1.
            if (!empty($config['options']['clean_target'])) {
                $cleanup = new \PrestaShift\Service\CleanupService();
                $cleanup->cleanTargetShop($config['scope']);
            }
            
            // CLEAR PREVIOUS SAVED STATE if this is a fresh start
            \Configuration::updateValue('PRESTASHIFT_MIGRATION_STATE', '');

            // Save config for post-migration tasks (redirect map needs connection info)
            \Configuration::updateValue('PRESTASHIFT_LAST_CONFIG', json_encode($config));

            $state = $manager->initSession($config);

            $response = [
                'success' => true,
                'message' => $this->module->l('Initialization complete. Target wiped (if selected). Starting batch...', 'AdminPrestaShiftMigrationController'),
                'next_batch' => true,
                'state' => $state
            ];

        } catch (Throwable $e) {
            $response = [
                'success' => false,
                'message' => $this->module->l('Error during initialization:', 'AdminPrestaShiftMigrationController') . ' ' . $e->getMessage()
            ];
        }
        
        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }

    /**
     * Post-migration cleanup tasks
     */
    public function ajaxProcesspostMigration()
    {
        ob_start();
        $tasks = [];

        // Only run catalog maintenance when the catalog was actually part of
        // this migration. Otherwise migrating just employees or customers would
        // trigger a full reindex of a pre-existing catalog — tens of minutes on
        // a large shop, for nothing.
        $raw = json_decode((string) \Configuration::get('PRESTASHIFT_LAST_CONFIG'), true);
        $config = (is_array($raw) && isset($raw['config'])) ? $raw['config'] : $raw;
        $scope = (is_array($config) && isset($config['scope']) && is_array($config['scope'])) ? $config['scope'] : [];
        $catalogMigrated = !empty($scope['catalog']);

        // A full inline reindex of a large catalog blocks the request for many
        // minutes and is fragile (memory, client disconnect). Above this size we
        // skip it and tell the operator to rebuild it with the shop's own tools.
        $productCount = (int) \Db::getInstance()->getValue("SELECT COUNT(*) FROM `" . _DB_PREFIX_ . "product`");
        $reindexThreshold = 2000;
        $reindexInline = $catalogMigrated && $productCount > 0 && $productCount <= $reindexThreshold;

        // 1. Regenerate category tree (catalog only)
        if ($catalogMigrated) {
            try {
                \Category::regenerateEntireNtree();
                $tasks[] = ['label' => $this->module->l('Category tree regenerated', 'AdminPrestaShiftMigrationController'), 'ok' => true];
            } catch (\Throwable $e) {
                $tasks[] = ['label' => $this->module->l('Category tree regeneration failed', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
            }
        }

        // 2. Rebuild search index (catalog only, small catalogs inline)
        if ($reindexInline) {
            try {
                if (class_exists('Search')) {
                    \Search::indexation(true);
                    $tasks[] = ['label' => $this->module->l('Search index rebuilt', 'AdminPrestaShiftMigrationController'), 'ok' => true];
                }
            } catch (\Throwable $e) {
                $tasks[] = ['label' => $this->module->l('Search index rebuild failed', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
            }
        } elseif ($catalogMigrated) {
            $tasks[] = ['label' => $this->module->l('Search index skipped — large catalog, rebuild it in Shop Parameters > Search.', 'AdminPrestaShiftMigrationController'), 'ok' => true];
        }

        // 3. Clear Smarty cache
        try {
            \Tools::clearSmartyCache();
            $tasks[] = ['label' => $this->module->l('Smarty cache cleared', 'AdminPrestaShiftMigrationController'), 'ok' => true];
        } catch (\Throwable $e) {
            $tasks[] = ['label' => $this->module->l('Smarty cache clear failed', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
        }

        // 4. Clear Symfony cache (PS 1.7+)
        try {
            $cacheDir = _PS_ROOT_DIR_ . '/var/cache/';
            if (is_dir($cacheDir . 'prod')) {
                \Tools::deleteDirectory($cacheDir . 'prod', false);
            }
            if (is_dir($cacheDir . 'dev')) {
                \Tools::deleteDirectory($cacheDir . 'dev', false);
            }
            $tasks[] = ['label' => $this->module->l('Symfony cache cleared', 'AdminPrestaShiftMigrationController'), 'ok' => true];
        } catch (\Throwable $e) {
            $tasks[] = ['label' => $this->module->l('Symfony cache clear failed', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
        }

        // 5. Rebuild faceted search index (catalog only, small catalogs inline)
        if ($reindexInline) {
            try {
                $facetedModule = \Module::getInstanceByName('ps_facetedsearch');
                if ($facetedModule && method_exists($facetedModule, 'fullPricesIndexProcess')) {
                    $facetedModule->fullPricesIndexProcess(0, false, false);
                    $tasks[] = ['label' => $this->module->l('Faceted search price index rebuilt', 'AdminPrestaShiftMigrationController'), 'ok' => true];
                }
                if ($facetedModule && method_exists($facetedModule, 'rebuildLayeredStructure')) {
                    $facetedModule->rebuildLayeredStructure();
                    $tasks[] = ['label' => $this->module->l('Faceted search structure rebuilt', 'AdminPrestaShiftMigrationController'), 'ok' => true];
                }
            } catch (\Throwable $e) {
                $tasks[] = ['label' => $this->module->l('Faceted search reindex failed', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
            }
        } elseif ($catalogMigrated) {
            $tasks[] = ['label' => $this->module->l('Faceted index skipped — large catalog, rebuild it from the Faceted Search module.', 'AdminPrestaShiftMigrationController'), 'ok' => true];
        }

        // 6. Remove orphaned product combinations (catalog only)
        if ($catalogMigrated) {
        try {
            $orphaned = (int)\Db::getInstance()->getValue(
                "SELECT COUNT(*) FROM `" . _DB_PREFIX_ . "product_attribute` pa
                 LEFT JOIN `" . _DB_PREFIX_ . "product_attribute_combination` pac ON pa.id_product_attribute = pac.id_product_attribute
                 WHERE pac.id_attribute IS NULL"
            );
            if ($orphaned > 0) {
                \Db::getInstance()->execute(
                    "DELETE pa, pas FROM `" . _DB_PREFIX_ . "product_attribute` pa
                     LEFT JOIN `" . _DB_PREFIX_ . "product_attribute_shop` pas ON pa.id_product_attribute = pas.id_product_attribute
                     LEFT JOIN `" . _DB_PREFIX_ . "product_attribute_combination` pac ON pa.id_product_attribute = pac.id_product_attribute
                     WHERE pac.id_attribute IS NULL"
                );
                $tasks[] = ['label' => sprintf($this->module->l('Removed %d orphaned combinations', 'AdminPrestaShiftMigrationController'), $orphaned), 'ok' => true];
            }
        } catch (\Throwable $e) {
            $tasks[] = ['label' => $this->module->l('Orphaned combinations cleanup failed', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
        }

        // 7. The search index flags are left as the indexer found them.
        //
        // This step used to mark every product as indexed, which told the shop
        // a lie: with a catalog over the inline threshold nothing had been
        // indexed at all, and "Add missing products to the index" — the very
        // button PrestaShop's migration guide points at — then had no work to
        // do, so the front-office search stayed empty. Search::indexation()
        // sets the flag itself for the products it indexes.
        } // end catalog-only maintenance

        // 6. Collect final report stats from target DB
        $report = [];
        $reportQueries = [
            'products'     => "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "product`",
            'categories'   => "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "category` WHERE id_category > 2",
            'customers'    => "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "customer`",
            'orders'       => "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "orders`",
            'images'       => "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "image`",
            'manufacturers'=> "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "manufacturer`",
            'cms_pages'    => "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "cms`",
            'carriers'     => "SELECT COUNT(*) as c FROM `" . _DB_PREFIX_ . "carrier` WHERE deleted = 0",
        ];
        foreach ($reportQueries as $key => $sql) {
            try {
                $report[$key] = (int)\Db::getInstance()->getValue($sql);
            } catch (\Throwable $e) {
                $report[$key] = 0;
            }
        }

        // 7. Generate redirect map
        // Friendly URLs: the setting alone is not enough.
        //
        // PrestaShop writes the rewrite rules into .htaccess when the setting
        // changes — Meta::update() and Meta::delete() end with
        // Tools::generateHtaccess(), and that method reads PS_REWRITING_SETTINGS
        // to decide what to write. This module writes the setting with
        // Configuration::updateValue() and the meta rows with SQL, so nothing
        // regenerated the file: a shop whose old site had friendly URLs on, and
        // whose new one had them off, ended up with the setting on and no rules
        // in .htaccess, which means 404 on every product and category page.
        if (!empty($scope['configuration'])) {
            try {
                if (\Configuration::get('PS_REWRITING_SETTINGS')) {
                    \Tools::generateHtaccess();
                    $tasks[] = ['label' => $this->module->l('Rewrite rules regenerated for friendly URLs', 'AdminPrestaShiftMigrationController'), 'ok' => true];
                }
            } catch (\Throwable $e) {
                $tasks[] = ['label' => $this->module->l('Rewrite rules regeneration failed — turn friendly URLs off and on again in Shop Parameters > Traffic & SEO', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
            }
        }

        $redirectFile = null;
        try {
            $savedState = (new \PrestaShift\Service\MigrationManager())->getSavedState();
            if (!$savedState) {
                $savedState = json_decode(\Configuration::get('PRESTASHIFT_LAST_CONFIG'), true);
            }
            // LAST_CONFIG holds the config itself; a saved state wraps it
            $cfg = (is_array($savedState) && isset($savedState['config'])) ? $savedState['config'] : $savedState;
            if (is_array($cfg) && isset($cfg['db_prefix'])) {
                $manager = new \PrestaShift\Service\MigrationManager();
                $conn = $manager->getConnection($cfg);
                \PrestaShift\Service\IdMapper::begin($conn, $cfg['db_prefix'], $cfg);
                $redirectFile = \PrestaShift\Service\RedirectMapService::generate(
                    $conn, $cfg['db_prefix'], $cfg['source_url'] ?? ''
                );
                if ($redirectFile && file_exists($redirectFile)) {
                    $tasks[] = ['label' => $this->module->l('Redirect map generated:', 'AdminPrestaShiftMigrationController') . ' ' . basename($redirectFile), 'ok' => true];
                }
            }
        } catch (\Throwable $e) {
            $tasks[] = ['label' => $this->module->l('Redirect map generation failed', 'AdminPrestaShiftMigrationController'), 'ok' => false, 'error' => $e->getMessage()];
        }

        $response = ['success' => true, 'tasks' => $tasks, 'report' => $report, 'redirect_file' => $redirectFile];
        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }

    public function ajaxProcessrunBatch()
    {
        // NUCLEAR DEBUGGING for Batch
        register_shutdown_function(function() {
            $error = error_get_last();
            if ($error && ($error['type'] === E_ERROR || $error['type'] === E_PARSE || $error['type'] === E_CORE_ERROR)) {
                http_response_code(500); 
                header('Content-Type: application/json');
                echo json_encode(['success' => false, 'message' => 'FATAL BATCH ERROR: ' . $error['message'] . ' in ' . $error['file'] . ':' . $error['line']]);
                die();
            }
        });

        ob_start();
        $stateRaw = Tools::getValue('state');
        
        // Decode JSON state if string (sent via JSON.stringify in JS)
        if (is_string($stateRaw)) {
            $state = json_decode($stateRaw, true);
        } else {
            $state = $stateRaw;
        }
        
        try {
            $manager = new \PrestaShift\Service\MigrationManager();
            // "use_bridge" exists only in a connector configuration, so reading
            // it directly raised "Undefined array key" on every direct database
            // migration. With debug mode on, PrestaShop turns that warning into
            // an error and the first batch died.
            if (!is_array($state) || !isset($state['config'])
                || (empty($state['config']['use_bridge']) && empty($state['config']['db_host']))) {
                 // Fallback info for debugging
                 $type = gettype($stateRaw);
                 throw new Exception("Invalid Migration State received. Config missing. Type: $type. Raw: " . substr(print_r($stateRaw, true), 0, 100));
            }
            $response = $manager->processBatch($state);
            
        } catch (Throwable $e) {
            // The batch runs inside one transaction (see
            // MigrationManager::processBatch). Undo it, so a batch that failed
            // halfway leaves nothing behind and Resume can run it again from a
            // whole state. MySQL would discard it when the connection closes
            // anyway; doing it here means the rest of this request, telemetry
            // included, no longer sits inside a dead transaction.
            try {
                \Db::getInstance()->execute('ROLLBACK');
            } catch (Throwable $ignored) {
            }

            // TELEMETRY: If user agreed, send the error report
            $config = $this->getMigrationConfig($state);
            $telemetry = new \PrestaShift\Service\TelemetryService();
            $telemetry->sendErrorReport([
                'message' => $e->getMessage(),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'task' => is_array($state) && isset($state['current_task']) ? $state['current_task'] : null,
                'offset' => is_array($state) && isset($state['offset']) ? $state['offset'] : null,
                'trace' => $e->getTraceAsString()
            ], $config);

            $response = [
                'success' => false,
                'next_batch' => false,
                'message' => $this->module->l('Batch Error:', 'AdminPrestaShiftMigrationController') . ' ' . $e->getMessage()
            ];
        }
        
        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }

    private function getMigrationConfig($state = null)
    {
        if ($state && isset($state['config'])) {
            return $state['config'];
        }
        
        $savedState = (new \PrestaShift\Service\MigrationManager())->getSavedState();
        if ($savedState && isset($savedState['config'])) {
            return $savedState['config'];
        }
        
        return [
            'source_url' => \PrestaShift\Service\ConnectorClient::shopUrl(Tools::getValue('source_url')),
            'options' => Tools::getValue('options', [])
        ];
    }

    public function ajaxProcessping()
    {
        ob_end_clean(); // Clean any previous buffers
        header('Content-Type: application/json');
        die(json_encode(['success' => true, 'message' => 'Pong!', 'class' => __CLASS__]));
    }

    public function ajaxProcessgetSavedState()
    {
        ob_start();
        $manager = new \PrestaShift\Service\MigrationManager();
        $state = $manager->getSavedState();
        
        $response = [
            'success' => true,
            'has_state' => !empty($state),
            'state' => $state
        ];
        
        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }

    public function ajaxProcessclearSavedState()
    {
        \Configuration::updateValue('PRESTASHIFT_MIGRATION_STATE', '');
        header('Content-Type: application/json');
        die(json_encode(['success' => true]));
    }

    public function ajaxProcessgetSourceStatuses()
    {
        ob_start();
        try {
            // The connection has to be built the way the user chose it. This
            // handler used to assume the connector, so on a direct database
            // connection the order status mapping answered "403 Forbidden"
            // from a connector the shop does not even have installed.
            $method = Tools::getValue('connection_method', 'bridge');
            $config = [
                'connection_method' => $method,
                'db_prefix' => Tools::getValue('db_prefix', 'ps_'),
                'source_url' => \PrestaShift\Service\ConnectorClient::shopUrl(Tools::getValue('source_url', '')),
            ];
            if ($method === 'direct') {
                $config['db_host'] = Tools::getValue('db_host', 'localhost');
                $config['db_port'] = (int) Tools::getValue('db_port', 3306);
                $config['db_name'] = Tools::getValue('db_name');
                $config['db_user'] = Tools::getValue('db_user');
                $config['db_pass'] = Tools::getValue('db_pass', '');
            } else {
                $config['bridge_token'] = Tools::getValue('bridge_token');
            }

            $manager = new \PrestaShift\Service\MigrationManager();
            $conn = $manager->getConnection($config);
            $prefix = $config['db_prefix'];

            // 1. Get ALL languages from source to find a valid one for names
            $langSql = "SELECT id_lang FROM `{$prefix}lang` WHERE active = 1 LIMIT 1";
            $langStmt = $conn->query($langSql);
            $sourceLangId = $langStmt->fetchColumn() ?: 1;

            // 2. Get Source Statuses
            $sql = "SELECT os.id_order_state, osl.name 
                    FROM `{$prefix}order_state` os 
                    LEFT JOIN `{$prefix}order_state_lang` osl ON (os.id_order_state = osl.id_order_state AND osl.id_lang = $sourceLangId)
                    ORDER BY os.id_order_state ASC";
            $stmt = $conn->query($sql);
            $sourceStatuses = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // 3. Get Local Statuses (Destination)
            $localLangId = (int)$this->context->language->id;
            $localStatuses = \Db::getInstance()->executeS("
                SELECT os.id_order_state, osl.name 
                FROM `"._DB_PREFIX_."order_state` os
                LEFT JOIN `"._DB_PREFIX_."order_state_lang` osl ON (os.id_order_state = osl.id_order_state AND osl.id_lang = $localLangId)
                ORDER BY os.id_order_state ASC
            ");

            $response = [
                'success' => true,
                'source_statuses' => $sourceStatuses,
                'local_statuses' => $localStatuses
            ];

        } catch (\Throwable $e) {
            $response = [
                'success' => false,
                'message' => $this->module->l('Error fetching statuses:', 'AdminPrestaShiftMigrationController') . ' ' . $e->getMessage()
            ];
        }

        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }

    public function ajaxProcessgetSourceZones()
    {
        ob_start();
        try {
            $method = Tools::getValue('connection_method', 'bridge');
            $config = [
                'connection_method' => $method,
                'db_prefix' => Tools::getValue('db_prefix', 'ps_'),
                'source_url' => \PrestaShift\Service\ConnectorClient::shopUrl(Tools::getValue('source_url', '')),
            ];
            if ($method === 'direct') {
                $config['db_host'] = Tools::getValue('db_host', 'localhost');
                $config['db_port'] = (int)Tools::getValue('db_port', 3306);
                $config['db_name'] = Tools::getValue('db_name');
                $config['db_user'] = Tools::getValue('db_user');
                $config['db_pass'] = Tools::getValue('db_pass', '');
            } else {
                $config['bridge_token'] = Tools::getValue('bridge_token');
            }

            $manager = new \PrestaShift\Service\MigrationManager();
            $conn = $manager->getConnection($config);
            $prefix = $config['db_prefix'];

            // Source zones
            $sourceZones = $conn->query(
                "SELECT id_zone, name FROM `{$prefix}zone` WHERE active = 1 ORDER BY name ASC"
            )->fetchAll(\PDO::FETCH_ASSOC);

            // Target zones
            $localZones = \Db::getInstance()->executeS(
                "SELECT id_zone, name FROM `" . _DB_PREFIX_ . "zone` WHERE active = 1 ORDER BY name ASC"
            );

            $response = [
                'success' => true,
                'source_zones' => $sourceZones,
                'local_zones' => $localZones
            ];

        } catch (\Throwable $e) {
            $response = [
                'success' => false,
                'message' => $this->module->l('Error fetching zones:', 'AdminPrestaShiftMigrationController') . ' ' . $e->getMessage()
            ];
        }

        $json = json_encode($response);
        ob_end_clean();
        header('Content-Type: application/json');
        die($json);
    }
}
