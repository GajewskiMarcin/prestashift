/**
 * PrestaShift Admin Scripts - V7 Corrected
 */
var PrestaShift = {
    currentStep: 1,
    connectionData: null,
    scopeData: null,
    optionsData: null,
    isPaused: false,
    pendingNextBatch: null,
    // A failed batch is tried again every retryDelay ms, maxRetries times
    // (about one minute), before the migration stops.
    retryDelay: 5000,
    maxRetries: 12,
    failedAttempts: 0,
    lastRetryError: null,
    stats: {
        products: 0,
        orders: 0,
        customers: 0
    },

    init: function () {
        this.loadStep(this.currentStep);
        this.bindEvents();
        if (this.currentStep === 1) {
            this.checkSavedState();
        }
    },

    t: function (key) {
        if (typeof ps_translations !== 'undefined' && ps_translations[key]) {
            return ps_translations[key];
        }
        return key;
    },

    // Delay (ms) to wait between batches, from the Options step.
    // A floor of 100ms keeps the loop from hammering the server even if the
    // user sets it very low; default 500ms when unset.
    getDelay: function () {
        var delay = 500;
        if (PrestaShift.optionsData) {
            $.each(PrestaShift.optionsData, function (i, field) {
                if (field.name === 'options[delay]') {
                    var v = parseInt(field.value, 10);
                    if (!isNaN(v)) {
                        delay = v;
                    }
                }
            });
        }
        return delay < 100 ? 100 : delay;
    },

    bindEvents: function () {
        // NOTE: btn-check-connection is handled via onclick attribute

        $(document).on('click', '#btn-submit-scope', function () {
            PrestaShift.scopeData = $('#scope-form').serializeArray();
            PrestaShift.currentStep = 3;
            PrestaShift.loadStep(3);
        });

        // Scope dependency logic: orders & messages require customers
        $(document).on('change', '#scope-form input[type="checkbox"]', function () {
            PrestaShift.enforceScopeDependencies();
        });

        $(document).on('click', '#btn-submit-options', function () {
            PrestaShift.optionsData = $('#options-form').serializeArray();
            PrestaShift.currentStep = 4;
            PrestaShift.loadStep(4);
        });

        $(document).on('click', '#btn-start-migration', function () {
            PrestaShift.startMigration();
        });

        $(document).on('click', '#btn-resume-migration', function () {
            PrestaShift.resumeMigration();
        });
    },

    toggleConnectionMethod: function () {
        var method = $('input[name="connection_method"]:checked').val();
        if (method === 'direct') {
            $('#bridge-form-container, #bridge-info').hide();
            $('#direct-form-container, #direct-info').show();
            $('input[name="connection_method"]:checked').closest('label').css('border-color', '#3b82f6').css('background', '#eff6ff');
            $('input[name="connection_method"]:not(:checked)').closest('label').css('border-color', '#e2e8f0').css('background', '');
        } else {
            $('#bridge-form-container, #bridge-info').show();
            $('#direct-form-container, #direct-info').hide();
            $('input[name="connection_method"]:checked').closest('label').css('border-color', '#3b82f6').css('background', '#eff6ff');
            $('input[name="connection_method"]:not(:checked)').closest('label').css('border-color', '#e2e8f0').css('background', '');
        }
    },

    checkConnection: function (e) {
        if (e) e.preventDefault();

        var method = $('input[name="connection_method"]:checked').val() || 'bridge';
        var formId = (method === 'direct') ? '#direct-connection-form' : '#connection-form';
        var formDataStr = $(formId).serialize();
        var formDataArray = $(formId).serializeArray();

        // Validate required fields
        if (method === 'bridge') {
            var urlVal = $(formId + ' input[name="source_url"]').val();
            var tokenVal = $(formId + ' input[name="bridge_token"]').val();
            if (!urlVal || !tokenVal) {
                $.growl.error({ title: PrestaShift.t('error'), message: PrestaShift.t('fill_all_fields') });
                return;
            }
        } else {
            var host = $(formId + ' input[name="db_host"]').val();
            var dbname = $(formId + ' input[name="db_name"]').val();
            var user = $(formId + ' input[name="db_user"]').val();
            if (!host || !dbname || !user) {
                $.growl.error({ title: PrestaShift.t('error'), message: PrestaShift.t('fill_db_fields') });
                return;
            }
        }

        var $btn = $('#btn-check-connection');
        $btn.prop('disabled', true).html('<i class="icon-refresh icon-spin"></i> ' + PrestaShift.t('testing'));

        $.ajax({
            url: controller_url,
            type: 'POST',
            data: formDataStr + '&ajax=true&action=check_connection',
            dataType: 'json',
            success: function (response) {
                $btn.prop('disabled', false).html(PrestaShift.t('test_connection_btn')); // Restore Text

                if (response.success) {
                    PrestaShift.connectionData = formDataArray;
                    PrestaShift.sourceVersion = response.source_version || 'unknown';
                    PrestaShift.targetVersion = response.target_version || 'unknown';

                    var msg = response.message + ' | ' + response.source_version + ' → ' + response.target_version;
                    $.growl.notice({ title: PrestaShift.t('success'), message: msg });

                    // Store warnings for display on step 2
                    PrestaShift.versionWarnings = response.warnings || [];
                    PrestaShift.sourceVersion = response.source_version || 'unknown';
                    PrestaShift.targetVersion = response.target_version || 'unknown';

                    // Move to Step 2
                    PrestaShift.currentStep = 2;
                    setTimeout(function () {
                        PrestaShift.loadStep(2);
                    }, 500);

                } else {
                    $.growl.error({ title: PrestaShift.t('error'), message: response.message });
                }
            },
            error: function (jqXHR, textStatus, errorThrown) {
                $btn.prop('disabled', false).html(PrestaShift.t('test_connection_btn'));
                $.growl.error({ title: PrestaShift.t('connection_error'), message: textStatus + ': ' + errorThrown });
                console.error('Connection Check Failed:', jqXHR);
            }
        });
    },

    loadStep: function (step) {
        $('#step-content').html('<div class="ps-text-center" style="padding:40px;"><i class="icon-spinner icon-spin icon-3x ps-text-blue-600"></i><p class="ps-text-slate-500">' + PrestaShift.t('loading') + '</p></div>');

        // Update Stepper Visuals locally
        $('.ps-step-content').removeClass('ps-step-active ps-step-completed');
        $('.ps-step-line').removeClass('ps-step-line-active');

        $('.ps-step-item').each(function () {
            var s = $(this).data('step');
            if (s < step) {
                $(this).find('.ps-step-content').addClass('ps-step-completed');
                $(this).find('.ps-step-line').addClass('ps-step-line-active');
            } else if (s == step) {
                $(this).find('.ps-step-content').addClass('ps-step-active');
            }
        });

        $.ajax({
            url: controller_url,
            type: 'POST',
            dataType: 'text',
            data: {
                ajax: true,
                action: 'render_step',
                step: step
            },
            success: function (raw, textStatus, jqXHR) {
                // The answer has to be JSON. A server that prepends PHP
                // notices, a login page or a security-token page lands here
                // too, so pull the JSON out and, when there is none, say what
                // actually came back.
                var response = PrestaShift.readJson(raw);
                if (!response) {
                    $('#step-content').html(PrestaShift.problemBox(PrestaShift.t('step_failed'), PrestaShift.describeAjaxError(jqXHR, 'parsererror', raw)));
                    return;
                }
                if (response.noise) {
                    console.warn('PrestaShift: the server added text before the answer:', response.noise);
                }
                if (response.content) {
                    $('#step-content').html(response.content);
                    PrestaShift.restoreData(step);

                    if (step === 2) {
                        PrestaShift.enforceScopeDependencies();
                        PrestaShift.showVersionWarnings();
                    }
                    if (step === 3) {
                        PrestaShift.loadStatusMapping();
                        PrestaShift.loadZoneMapping();
                        PrestaShift.bindStepEvents(3);
                    }
                    if (step === 4) {
                        PrestaShift.prepareSummary();
                        PrestaShift.loadPreview();
                    }

                } else {
                    $('#step-content').html('<div class="alert alert-danger">Empty content</div>');
                }
            },
            error: function (jqXHR, textStatus) {
                $('#step-content').html(PrestaShift.problemBox(PrestaShift.t('step_failed'), PrestaShift.describeAjaxError(jqXHR, textStatus)));
            }
        });
    },

    /**
     * Reads the module's JSON answer. Some servers prepend PHP notices or an
     * HTML page to it, which used to surface only as "failed to load".
     */
    readJson: function (raw) {
        if (typeof raw !== 'string') {
            return raw || null;
        }
        try {
            return JSON.parse(raw);
        } catch (e) {
            var start = raw.indexOf('{');
            var end = raw.lastIndexOf('}');
            if (start > -1 && end > start) {
                try {
                    var data = JSON.parse(raw.substring(start, end + 1));
                    data.noise = raw.substring(0, start);
                    return data;
                } catch (e2) {
                    return null;
                }
            }
            return null;
        }
    },

    /**
     * Turns a failed request into something the shop owner can act on:
     * the likely cause, the HTTP status and what the server actually sent.
     */
    describeAjaxError: function (jqXHR, textStatus, raw) {
        var status = jqXHR && jqXHR.status ? jqXHR.status : 0;
        var body = (raw !== undefined ? raw : (jqXHR && jqXHR.responseText) || '');
        var text = $('<div>').html(String(body).replace(/<script[^]*?<\/script>/gi, '')).text().replace(/\s+/g, ' ').trim();

        var reason;
        if (status === 0) {
            reason = PrestaShift.t('err_no_answer');
        } else if (status === 401 || status === 403 || /invalid security token/i.test(text)) {
            reason = PrestaShift.t('err_session');
        } else if (status === 404) {
            reason = PrestaShift.t('err_not_found');
        } else if (status >= 500) {
            reason = PrestaShift.t('err_server');
        } else if (textStatus === 'parsererror') {
            reason = PrestaShift.t('err_not_json');
        } else {
            reason = PrestaShift.t('error');
        }

        return reason + (status ? ' (HTTP ' + status + ')' : '')
            + (text ? '<br><code style="display:block; margin-top:.5rem; white-space:pre-wrap; word-break:break-word; font-size:.75rem;">'
                + $('<div>').text(text.substring(0, 400)).html() + '</code>' : '');
    },

    problemBox: function (title, detail) {
        return '<div class="alert alert-danger" style="text-align:left;"><strong>' + title + '</strong><br>' + detail + '</div>';
    },

    restoreData: function (step) {
        if (step === 1 && PrestaShift.connectionData) {
            $.each(PrestaShift.connectionData, function (i, field) { $('[name="' + field.name + '"]').val(field.value); });
        }
        if (step === 2 && PrestaShift.scopeData) {
            $.each(PrestaShift.scopeData, function (i, field) {
                var $el = $('[name="' + field.name + '"]');
                if ($el.is(':checkbox')) $el.prop('checked', true);
                else $el.val(field.value);
            });
        }
        if (step === 3 && PrestaShift.optionsData) {
            $.each(PrestaShift.optionsData, function (i, field) {
                var $el = $('[name="' + field.name + '"]');
                if ($el.is(':checkbox')) $el.prop('checked', true);
                else $el.val(field.value);
            });
        }
    },

    bindStepEvents: function (step) {
        if (step === 3) {
            // Mutual exclusivity: Incremental vs Clean Target
            $(document).off('change', '#opt-incremental').on('change', '#opt-incremental', function () {
                if ($(this).is(':checked')) {
                    $('#opt-clean-target').prop('checked', false).trigger('change');
                }
            });
            $(document).off('change', '#opt-clean-target').on('change', '#opt-clean-target', function () {
                if ($(this).is(':checked')) {
                    $('#opt-incremental').prop('checked', false).trigger('change');
                }
            });
        }
    },

    prepareSummary: function () {
        var sourceUrl = PrestaShift.t('unknown');
        var cleanTarget = PrestaShift.t('no');

        if (PrestaShift.connectionData) {
            $.each(PrestaShift.connectionData, function (i, field) {
                if (field.name === 'source_url') sourceUrl = field.value;
            });
        }
        if (PrestaShift.optionsData) {
            $.each(PrestaShift.optionsData, function (i, field) {
                if (field.name === 'options[clean_target]' && field.value == '1') cleanTarget = PrestaShift.t('yes_clean');
            });
        }

        $('#summary-source').text(sourceUrl);
        $('#summary-clean').text(cleanTarget);

        // Simplified entities logic for now
        PrestaShift.checkSavedState();
    },

    loadZoneMapping: function () {
        var carriersEnabled = false;
        if (PrestaShift.scopeData) {
            $.each(PrestaShift.scopeData, function (i, field) {
                if (field.name === 'scope[carriers]' && field.value == '1') carriersEnabled = true;
            });
        }
        if (!carriersEnabled) { $('#zone-mapping-area').hide(); return; }

        $('#zone-mapping-area').show();
        var allData = [];
        if (PrestaShift.connectionData) allData = allData.concat(PrestaShift.connectionData);
        var formData = $.param(allData);

        $.ajax({
            url: controller_url,
            type: 'POST',
            data: formData + '&ajax=true&action=get_source_zones',
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    PrestaShift.renderZoneTable(response.source_zones, response.local_zones);
                } else {
                    $('#zone-mapping-table-container').html('<div class="alert alert-danger">' + (response.message || PrestaShift.t('error')) + '</div>');
                }
            },
            error: function (jqXHR, textStatus) {
                $('#zone-mapping-table-container').html(PrestaShift.problemBox(PrestaShift.t('zones_error'), PrestaShift.describeAjaxError(jqXHR, textStatus)));
            }
        });
    },

    renderZoneTable: function (sourceZones, localZones) {
        var html = '<div class="ps-space-y-2">';
        $.each(sourceZones, function (i, source) {
            html += '<div class="ps-flex-between ps-p-3 ps-border ps-border-slate-200 ps-rounded-md ps-bg-slate-50">';

            html += '<div class="ps-flex-start ps-gap-2" style="flex: 1;">';
            html += '<span class="ps-font-medium ps-text-slate-700">' + source.name + '</span>';
            html += '<span class="ps-text-xs ps-text-slate-400">(ID: ' + source.id_zone + ')</span>';
            html += '</div>';

            html += '<div class="ps-text-slate-400" style="padding: 0 24px;"><i class="icon-long-arrow-right"></i></div>';

            html += '<div style="min-width: 250px;">';
            html += '<select name="zone_map[' + source.id_zone + ']" class="ps-input" style="height: 36px; padding: 4px 8px;">';
            html += '<option value="">-- skip --</option>';
            var found = false;
            $.each(localZones, function (j, local) {
                var selected = "";
                if (!found && local.name.toLowerCase().trim() == source.name.toLowerCase().trim()) {
                    selected = "selected"; found = true;
                }
                html += '<option value="' + local.id_zone + '" ' + selected + '>' + local.name + '</option>';
            });
            html += '</select></div></div>';
        });
        html += '</div>';
        $('#zone-mapping-table-container').html(html);
    },

    loadPreview: function () {
        var allData = [];
        if (PrestaShift.connectionData) allData = allData.concat(PrestaShift.connectionData);
        var formData = $.param(allData);

        $.ajax({
            url: controller_url,
            type: 'POST',
            data: formData + '&ajax=true&action=preview',
            dataType: 'json',
            success: function (response) {
                if (response.success && response.counts) {
                    var c = response.counts;
                    var labels = {
                        products: PrestaShift.t('lbl_products'), categories: PrestaShift.t('lbl_categories'), customers: PrestaShift.t('lbl_customers'),
                        orders: PrestaShift.t('lbl_orders'), manufacturers: PrestaShift.t('lbl_manufacturers'), carriers: PrestaShift.t('lbl_carriers'),
                        cms: PrestaShift.t('lbl_cms_pages'), images: PrestaShift.t('lbl_images'), cart_rules: PrestaShift.t('lbl_cart_rules'),
                        reviews: PrestaShift.t('lbl_reviews')
                    };
                    // Map preview keys to scope keys
                    var scopeMap = {
                        products: 'catalog', categories: 'catalog', manufacturers: 'manufacturers',
                        customers: 'customers', orders: 'orders', carriers: 'carriers',
                        cms: 'cms', images: 'images', cart_rules: 'cart_rules'
                    };
                    // Check which scopes are enabled
                    var enabledScopes = {};
                    if (PrestaShift.scopeData) {
                        $.each(PrestaShift.scopeData, function (i, field) {
                            var m = field.name.match(/^scope\[(\w+)\]$/);
                            if (m && field.value == '1') enabledScopes[m[1]] = true;
                        });
                    }
                    var html = '<div style="display:grid; grid-template-columns:repeat(3,1fr); gap:8px;">';
                    var shown = 0;
                    $.each(c, function (key, count) {
                        var reqScope = scopeMap[key];
                        if (reqScope && !enabledScopes[reqScope]) return; // skip disabled scopes
                        var label = labels[key] || key;
                        var color = count > 0 ? '#1e40af' : '#94a3b8';
                        html += '<div style="text-align:center; padding:8px; background:white; border-radius:6px; border:1px solid #e2e8f0;">';
                        html += '<div style="font-size:1.25rem; font-weight:700; color:' + color + ';">' + new Intl.NumberFormat().format(count) + '</div>';
                        html += '<div style="font-size:0.75rem; color:#64748b;">' + label + '</div>';
                        html += '</div>';
                        shown++;
                    });
                    html += '</div>';
                    if (shown === 0) html = '<p style="color:#64748b; text-align:center;">No data scopes selected</p>';
                    $('#preview-data').html(html);
                } else {
                    $('#preview-data').html('<span style="color:#dc2626;">Could not load preview</span>');
                }
            },
            error: function () {
                $('#preview-data').html('<span style="color:#94a3b8;">Preview unavailable</span>');
            }
        });
    },

    runPostMigration: function () {
        $.ajax({
            url: controller_url,
            type: 'POST',
            data: 'ajax=true&action=post_migration',
            dataType: 'json',
            success: function (response) {
                if (response.success && response.tasks) {
                    $.each(response.tasks, function (i, t) {
                        var icon = t.ok ? '&#10003;' : '&#10007;';
                        var color = t.ok ? '#16a34a' : '#dc2626';
                        PrestaShift.log('<span style="color:' + color + ';">' + icon + '</span> ' + t.label);
                    });
                }
                PrestaShift.log('<strong>Migration Completed.</strong>');

                // Build final stats grid from report, filtered by selected scopes
                if (response.report) {
                    var r = response.report;
                    var reportLabels = {
                        products: PrestaShift.t('lbl_products'), categories: PrestaShift.t('lbl_categories'), customers: PrestaShift.t('lbl_customers'),
                        orders: PrestaShift.t('lbl_orders'), manufacturers: PrestaShift.t('lbl_manufacturers'), cms_pages: PrestaShift.t('lbl_cms_pages'),
                        images: PrestaShift.t('lbl_images'), carriers: PrestaShift.t('lbl_carriers'), reviews: PrestaShift.t('lbl_reviews')
                    };
                    var reportScopeMap = {
                        products: 'catalog', categories: 'catalog', manufacturers: 'manufacturers',
                        customers: 'customers', orders: 'orders', carriers: 'carriers',
                        cms_pages: 'cms', images: 'images'
                    };
                    var enabledScopes = {};
                    if (PrestaShift.scopeData) {
                        $.each(PrestaShift.scopeData, function (i, field) {
                            var m = field.name.match(/^scope\[(\w+)\]$/);
                            if (m && field.value == '1') enabledScopes[m[1]] = true;
                        });
                    }
                    var statsHtml = '';
                    var colors = ['#2563eb', '#7c3aed', '#059669', '#d97706', '#dc2626', '#0891b2', '#4f46e5', '#16a34a'];
                    var ci = 0;
                    $.each(r, function (key, count) {
                        var reqScope = reportScopeMap[key];
                        if (reqScope && !enabledScopes[reqScope]) return;
                        var label = reportLabels[key] || key;
                        var color = colors[ci % colors.length]; ci++;
                        statsHtml += '<div style="padding: 2rem 1rem; border-right: 1px solid #e2e8f0;">';
                        statsHtml += '<p style="font-size:1.875rem; font-weight:700; color:' + color + '; margin-bottom:0.5rem;">' + new Intl.NumberFormat().format(count) + '</p>';
                        statsHtml += '<p class="ps-text-sm ps-text-slate-500 ps-font-medium">' + label + '</p>';
                        statsHtml += '</div>';
                    });
                    $('#final-stats-grid').html(statsHtml);
                }

                PrestaShift.showUrlReport(response.urls);

                $('#main-progress-bar').css('width', '100%');
                $('#main-progress-text').text('100%');
                $('#migration-progress-container').hide();
                $('#migration-finished-container').show();
            },
            error: function () {
                PrestaShift.logError(PrestaShift.t('post_tasks_failed'));
                $('#migration-progress-container').hide();
                $('#migration-finished-container').show();
            }
        });
    },

    // What happened to the old addresses of the source, and the server rules
    // to download. Translations are HTML already; what the server reports
    // (file name, rules) is escaped.
    showUrlReport: function (urls) {
        var $box = $('#url-report');
        if (!$box.length || !urls) {
            return;
        }

        var count = parseInt(urls.count, 10) || 0;
        var lines = [];
        if (!count) {
            lines.push(PrestaShift.t('urls_none'));
        } else {
            lines.push(PrestaShift.t('urls_count').replace('%d', count));
            if (urls.mode === 'match') {
                lines.push(PrestaShift.t('urls_match_left'));
            } else if (String(urls.mode).indexOf('htaccess') === 0) {
                var keys = { verified: 'urls_ht_verified', unverified: 'urls_ht_unverified', ignored: 'urls_ht_ignored', restored: 'urls_ht_restored' };
                var status = urls.htaccess && keys[urls.htaccess.status] ? keys[urls.htaccess.status] : 'urls_ht_failed';
                var backup = urls.htaccess && urls.htaccess.backup ? PrestaShift.escapeHtml(urls.htaccess.backup) : '';
                lines.push(PrestaShift.t(status).replace('%s', backup));
            } else {
                lines.push(PrestaShift.t('urls_nginx'));
            }
            if (parseInt(urls.outside, 10) > 0) {
                lines.push(PrestaShift.t('urls_outside').replace('%d', parseInt(urls.outside, 10)));
            }
        }

        var html = '<h3 class="ps-font-semibold ps-text-slate-900">' + PrestaShift.t('urls_title') + '</h3>';
        $.each(lines, function (i, line) {
            html += '<p class="ps-text-slate-600">' + line + '</p>';
        });
        if (count && String(urls.mode).indexOf('nginx') === 0 && urls.nginx_preview) {
            html += '<textarea readonly class="ps-input" rows="12" style="width: 100%; font-family: monospace; font-size: 12px;">' + PrestaShift.escapeHtml(urls.nginx_preview) + '</textarea>';
        }
        if (count && urls.files) {
            html += '<div style="display: flex; flex-wrap: wrap; gap: 1rem;">';
            $.each(['htaccess', 'nginx'], function (i, type) {
                if (urls.files[type]) {
                    var href = controller_url + '&ajax=1&action=download_redirects&type=' + type;
                    html += '<a class="ps-btn ps-btn-outline" href="' + PrestaShift.escapeHtml(href) + '">' + PrestaShift.t('urls_download_' + type) + '</a>';
                }
            });
            html += '</div>';
        }

        $box.html(html).show();
    },

    showVersionWarnings: function () {
        if (!PrestaShift.versionWarnings || PrestaShift.versionWarnings.length === 0) return;
        var html = '<div class="ps-card ps-p-4" style="border:1px solid #f59e0b; background:#fffbeb; margin-bottom:1.5rem;">';
        html += '<div class="ps-flex-start ps-gap-2" style="margin-bottom:8px;">';
        html += '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
        html += '<span class="ps-font-semibold" style="color:#92400e;">' + PrestaShift.sourceVersion + ' → ' + PrestaShift.targetVersion + '</span>';
        html += '</div>';
        html += '<ul style="margin:0; padding-left:1.2rem; color:#78350f; font-size:0.875rem;">';
        $.each(PrestaShift.versionWarnings, function (i, w) {
            html += '<li style="margin-bottom:4px;">' + w + '</li>';
        });
        html += '</ul></div>';
        $('#scope-form').before(html);
    },

    enforceScopeDependencies: function () {
        var $form = $('#scope-form');
        if (!$form.length) return;

        // If customers is OFF, disable orders and messages
        var customersOn = $form.find('input[name="scope[customers]"]').is(':checked');
        var $orders = $form.find('input[name="scope[orders]"]');
        var $messages = $form.find('input[name="scope[messages]"]');

        if (!customersOn) {
            $orders.prop('checked', false).prop('disabled', true);
            $messages.prop('checked', false).prop('disabled', true);
            $orders.closest('.ps-checkbox-wrapper').css('opacity', '0.5');
            $messages.closest('.ps-checkbox-wrapper').css('opacity', '0.5');
        } else {
            $orders.prop('disabled', false);
            $messages.prop('disabled', false);
            $orders.closest('.ps-checkbox-wrapper').css('opacity', '1');
            $messages.closest('.ps-checkbox-wrapper').css('opacity', '1');
        }
    },

    loadStatusMapping: function () {
        var ordersEnabled = false;
        if (PrestaShift.scopeData) {
            $.each(PrestaShift.scopeData, function (i, field) {
                if (field.name === 'scope[orders]' && field.value == '1') ordersEnabled = true;
            });
        }
        if (!ordersEnabled) { $('#status-mapping-area').hide(); return; }

        $('#status-mapping-area').show();
        var allData = [];
        if (PrestaShift.connectionData) allData = allData.concat(PrestaShift.connectionData);
        var formData = $.param(allData);

        $.ajax({
            url: controller_url,
            type: 'POST',
            data: formData + '&ajax=true&action=get_source_statuses',
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    PrestaShift.renderStatusTable(response.source_statuses, response.local_statuses);
                } else {
                    $('#status-mapping-table-container').html('<div class="alert alert-danger">' + response.message + '</div>');
                }
            },
            error: function (jqXHR, textStatus) {
                $('#status-mapping-table-container').html(PrestaShift.problemBox(PrestaShift.t('statuses_error'), PrestaShift.describeAjaxError(jqXHR, textStatus)));
            }
        });
    },

    renderStatusTable: function (sourceConfigs, localStatuses) {
        var html = '<div class="ps-space-y-2">';
        $.each(sourceConfigs, function (i, source) {
            html += '<div class="ps-flex-between ps-p-3 ps-border ps-border-slate-200 ps-rounded-md ps-bg-slate-50">';

            // Name Column: flex: 1 to push arrow/select to the right
            html += '<div class="ps-flex-start ps-gap-2" style="flex: 1;">';
            html += '<span class="ps-font-medium ps-text-slate-700">' + source.name + '</span>';
            html += '<span class="ps-text-xs ps-text-slate-400">(' + source.id_order_state + ')</span>';
            html += '</div>';

            // Arrow: Padding to avoid sticking
            html += '<div class="ps-text-slate-400" style="padding: 0 24px;"><i class="icon-long-arrow-right"></i></div>';

            // Select: Fixed min-width
            html += '<div style="min-width: 250px;">';
            html += '<select name="status_map[' + source.id_order_state + ']" class="ps-input" style="height: 36px; padding: 4px 8px;">';
            var found = false;
            $.each(localStatuses, function (j, local) {
                var selected = "";
                if (!found && local.name.toLowerCase().trim() == source.name.toLowerCase().trim()) {
                    selected = "selected"; found = true;
                }
                html += '<option value="' + local.id_order_state + '" ' + selected + '>' + local.name + '</option>';
            });
            html += '</select></div></div>';
        });
        html += '</div>';
        $('#status-mapping-table-container').html(html);
    },

    startMigration: function () {
        var allData = [];
        if (PrestaShift.connectionData) allData = allData.concat(PrestaShift.connectionData);
        if (PrestaShift.scopeData) allData = allData.concat(PrestaShift.scopeData);
        if (PrestaShift.optionsData) allData = allData.concat(PrestaShift.optionsData);
        var formData = $.param(allData);

        // Run preflight checks first
        PrestaShift.log(PrestaShift.t('preflight_running'));
        $.ajax({
            url: controller_url,
            type: 'POST',
            data: 'ajax=true&action=pre_flight',
            dataType: 'json',
            success: function (response) {
                if (response.success && response.checks) {
                    var html = '';
                    var hasWarnings = false;
                    $.each(response.checks, function (i, c) {
                        var icon = c.ok ? '<span style="color:#16a34a;">&#10003;</span>' : '<span style="color:#dc2626;">&#10007;</span>';
                        html += '<div style="display:flex;gap:8px;align-items:center;padding:4px 0;">';
                        html += icon + ' <strong>' + c.label + '</strong>: ' + c.value;
                        if (c.hint) { html += ' <em style="color:#92400e;">— ' + c.hint + '</em>'; hasWarnings = true; }
                        html += '</div>';
                    });
                    PrestaShift.log(html);

                    if (!response.all_ok) {
                        PrestaShift.log('<strong style="color:#dc2626;">Pre-flight warnings detected. Migration will proceed but may encounter issues.</strong>');
                    }
                }

                // Proceed with migration
                $('#migration-start-container').hide();
                $('#migration-progress-container').show();
                PrestaShift.log(PrestaShift.t('starting_migration'));
                PrestaShift.runBatch(formData);
            },
            error: function () {
                // Preflight failed, start anyway
                $('#migration-start-container').hide();
                $('#migration-progress-container').show();
                PrestaShift.log(PrestaShift.t('starting_migration'));
                PrestaShift.runBatch(formData);
            }
        });
    },

    runBatch: function (data) {
        var ajaxData = (typeof data === 'string') ? data + '&ajax=true&action=start_migration' : data;

        // Tells the server this is a repeated attempt: the failure was
        // already reported the first time.
        if (PrestaShift.failedAttempts && typeof ajaxData !== 'string') {
            ajaxData = $.extend({}, ajaxData, { attempt: PrestaShift.failedAttempts });
        }

        $.ajax({
            url: controller_url,
            type: 'POST',
            data: ajaxData,
            dataType: 'json',
            success: function (response) {
                if (response.success) {
                    PrestaShift.failedAttempts = 0;
                    PrestaShift.lastRetryError = null;
                    PrestaShift.log(response.message);
                    $('#current-action').text(response.message);

                    // Rows the target database refused: the migration goes on,
                    // but they must not pass unnoticed.
                    $.each(response.warnings || [], function (i, warning) {
                        PrestaShift.logError(warning);
                    });

                    // Track stats
                    if (response.state && response.state.current_task) {
                        var task = response.state.current_task;
                        var count = response.batch_count || 0; // Backend might need to provide this or we parse it

                        if (task === 'products') PrestaShift.stats.products += count;
                        if (task === 'orders') PrestaShift.stats.orders += count;
                        if (task === 'customers') PrestaShift.stats.customers += count;
                    }

                    if (response.progress) {
                        $('#main-progress-bar').css('width', response.progress + '%');
                        $('#main-progress-text').text(response.progress + '%');
                    }
                    if (response.next_batch) {
                        var nextPayload = { ajax: true, action: 'run_batch', state: JSON.stringify(response.state) };

                        if (PrestaShift.isPaused) {
                            PrestaShift.pendingNextBatch = nextPayload;
                            PrestaShift.log(PrestaShift.t('migration_paused'));
                            $('#btn-pause-migration')
                                .html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-play" style="margin-right: 8px;"><polygon points="5 3 19 12 5 21 5 3"/></svg> Resume Migration')
                                .removeClass('ps-opacity-50')
                                .prop('disabled', false);
                            $('#finish-later-area').css('visibility', 'visible');
                        } else {
                            // Wait the configured delay before firing the next batch.
                            // Back-to-back requests to the same admin URL trip hosting
                            // rate limiters (429 Too Many Requests) on real servers.
                            setTimeout(function () {
                                PrestaShift.runBatch(nextPayload);
                            }, PrestaShift.getDelay());
                        }
                    } else {
                        // Run post-migration tasks before showing finished screen
                        PrestaShift.log(PrestaShift.t('transfer_complete'));
                        $('#current-action').text(PrestaShift.t('post_tasks_running'));
                        PrestaShift.runPostMigration();
                    }
                } else {
                    // Rate limit: the connector already retried server-side and
                    // still got 429. Wait longer (the limit window may be
                    // per-minute) and auto-resume the same batch — writes are
                    // idempotent, so re-running is safe. Any other error is
                    // tried again a few times, then stops.
                    if (response.message && /\b429\b|rate-limit|too many requests/i.test(response.message)) {
                        PrestaShift.logError(response.message);
                        PrestaShift.log(PrestaShift.t('rate_limit_wait'));
                        setTimeout(function () {
                            PrestaShift.runBatch(data);
                        }, 45000);
                    } else if (response.busy) {
                        // The shop is still working on the request this one
                        // repeats: nothing failed, so no attempt is used up.
                        if (PrestaShift.lastRetryError !== response.message) {
                            PrestaShift.lastRetryError = response.message;
                            PrestaShift.log(PrestaShift.escapeHtml(response.message));
                        }
                        PrestaShift.runBatchLater(data);
                    } else {
                        PrestaShift.retryBatch(data, PrestaShift.t('error_prefix') + response.message);
                    }
                }
            },
            error: function (jqXHR) {
                // Surface the server's real error instead of only a generic
                // network message. On a fatal PHP error the controller returns
                // HTTP 500 with the actual message (and file:line) in the body;
                // without this it was thrown away and the cause stayed hidden.
                var detail = '';
                if (jqXHR && jqXHR.responseJSON && jqXHR.responseJSON.message) {
                    detail = jqXHR.responseJSON.message;
                } else if (jqXHR && typeof jqXHR.responseText === 'string' && jqXHR.responseText) {
                    detail = jqXHR.responseText.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim().substring(0, 400);
                }
                if (jqXHR && jqXHR.status) {
                    detail = 'HTTP ' + jqXHR.status + (detail ? ' — ' + detail : '');
                }
                PrestaShift.retryBatch(data, detail || PrestaShift.t('err_no_answer'));
            }
        });
    },

    // A failed batch is tried again before the migration stops: a dropped
    // connection, a busy database or a gateway timeout usually pass on their
    // own. Running the same batch again is safe — its writes are idempotent,
    // and the server runs one migration request at a time.
    retryBatch: function (data, message) {
        if (PrestaShift.failedAttempts >= PrestaShift.maxRetries) {
            PrestaShift.failedAttempts = 0;
            PrestaShift.lastRetryError = null;
            PrestaShift.logError(message);
            PrestaShift.logError(PrestaShift.t('retry_gave_up').replace('%d', PrestaShift.maxRetries));
            PrestaShift.isPaused = true;
            PrestaShift.waitForResume(data);
            return;
        }

        PrestaShift.failedAttempts++;
        // The same error twelve times over would bury the rest of the log
        if (PrestaShift.lastRetryError !== message) {
            PrestaShift.lastRetryError = message;
            PrestaShift.logError(message);
        }
        PrestaShift.log(PrestaShift.t('retry_wait')
            .replace('%1$d', Math.round(PrestaShift.retryDelay / 1000))
            .replace('%2$d', PrestaShift.failedAttempts)
            .replace('%3$d', PrestaShift.maxRetries));
        PrestaShift.runBatchLater(data);
    },

    runBatchLater: function (data) {
        setTimeout(function () {
            if (PrestaShift.isPaused) {
                PrestaShift.log(PrestaShift.t('migration_paused'));
                PrestaShift.waitForResume(data);
                return;
            }
            PrestaShift.runBatch(data);
        }, PrestaShift.retryDelay);
    },

    waitForResume: function (data) {
        PrestaShift.pendingNextBatch = data;

        $('#btn-pause-migration')
            .html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-play" style="margin-right: 8px;"><polygon points="5 3 19 12 5 21 5 3"/></svg> Resume Migration')
            .removeClass('ps-opacity-50')
            .prop('disabled', false)
            .show();
        $('#finish-later-area').css('visibility', 'visible');
    },

    log: function (msg) {
        var $log = $('#migration-log');
        if (!$log.length) return;

        var time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
        var html = '<div class="ps-terminal-line">' +
            '<span class="ps-terminal-time">[' + time + ']</span>' +
            '<span class="ps-terminal-msg">' + msg + '</span>' +
            '</div>';

        $log.append(html);

        var $container = $('#migration-log-container');
        if ($container.length) {
            $container.scrollTop($container[0].scrollHeight);
        }
    },

    // Escape HTML so server-originated text (e.g. a 429 error page returned by
    // the source host) shows as readable text instead of rendering as markup —
    // which produced huge, dark, near-invisible text on the dark terminal.
    escapeHtml: function (s) {
        return $('<div>').text(s == null ? '' : String(s)).html();
    },

    // Log an error line: escaped (never rendered as HTML) and coloured so it
    // stands out clearly against the dark log background.
    logError: function (msg) {
        PrestaShift.log('<span class="ps-terminal-error" style="color:#f87171;font-weight:600;">' + PrestaShift.escapeHtml(msg) + '</span>');
    },

    checkSavedState: function () {
        $.ajax({
            url: controller_url,
            type: 'POST',
            data: { ajax: true, action: 'get_saved_state' },
            dataType: 'json',
            success: function (response) {
                if (response.success && response.has_state) {
                    var s = response.state;
                    var taskName = s.current_task || PrestaShift.t('unknown');
                    var offset = s.offset || 0;

                    var html = '<div class="ps-card ps-p-6 ps-bg-amber-50 ps-border-amber-400" style="display: flex; justify-content: space-between; align-items: center; gap: 1.5rem;">' +
                        '  <div class="ps-flex-start ps-gap-3">' +
                        '    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#d97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-alert-triangle"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" x2="12" y1="9" y2="13"/><line x1="12" x2="12" y1="17" y2="17.01"/></svg>' +
                        '    <div class="ps-space-y-1">' +
                        '      <p class="ps-font-bold ps-text-slate-900">' + PrestaShift.t('detected_interrupted') + '</p>' +
                        '      <p class="ps-text-sm ps-text-slate-600">' + PrestaShift.t('resuming') + ' <strong>' + PrestaShift.t(taskName) + '</strong> ' + PrestaShift.t('offset') + offset + '</p>' +
                        '    </div>' +
                        '  </div>' +
                        '  <div style="display: flex; gap: 1rem; align-items: center;">' +
                        '    <button type="button" class="ps-btn ps-btn-primary" id="btn-resume-session">' + PrestaShift.t('resume_button') + '</button>' +
                        '    <a href="#" class="ps-text-xs ps-text-slate-500 ps-font-medium" id="btn-clear-session" style="text-decoration: underline;">' + PrestaShift.t('reset_session') + '</a>' +
                        '  </div>' +
                        '</div>';

                    $('#resume-session-area').html(html).fadeIn();

                    $('#btn-resume-session').on('click', function () {
                        PrestaShift.resumeMigration(s);
                    });

                    $('#btn-clear-session').on('click', function (e) {
                        e.preventDefault();
                        if (confirm(PrestaShift.t('confirm_clear_session'))) {
                            PrestaShift.clearSavedState();
                        }
                    });
                }
            }
        });
    },

    resumeMigration: function (state) {
        // 1. Mark Steps 1-3 as completed in UI
        $('#migration-stepper .ps-step-item').each(function () {
            var s = parseInt($(this).data('step'));
            if (s < 4) {
                $(this).find('.ps-step-content').removeClass('ps-step-active').addClass('ps-step-completed');
                $(this).find('.ps-step-line').addClass('ps-step-line-active');
            } else if (s === 4) {
                $(this).find('.ps-step-content').addClass('ps-step-active');
            }
        });

        // 2. Load Step 4 template and start batching
        $.ajax({
            url: controller_url,
            type: 'POST',
            data: { ajax: true, action: 'render_step', step: 4 },
            dataType: 'json',
            success: function (response) {
                $('#step-content').html(response.content);
                $('#migration-start-container').hide();
                $('#migration-progress-container').show();

                PrestaShift.log(PrestaShift.t('resuming') + ' ' + PrestaShift.t(state.current_task));

                var firstPayload = {
                    ajax: true,
                    action: 'run_batch',
                    state: JSON.stringify(state)
                };
                PrestaShift.runBatch(firstPayload);
            }
        });
    },

    clearSavedState: function () {
        $.ajax({
            url: controller_url,
            type: 'POST',
            data: { ajax: true, action: 'clear_saved_state' },
            dataType: 'json',
            success: function () {
                $('#resume-session-area').fadeOut();
            }
        });
    },

    pauseMigration: function () {
        if (this.isPaused) {
            this.resumeMigrationInPlace();
            return;
        }

        this.isPaused = true;
        $('#btn-pause-migration').html('<i class="icon-spinner icon-spin"></i> Pausing...');
        $('#btn-pause-migration').addClass('ps-opacity-50').prop('disabled', true);
    },

    resumeMigrationInPlace: function () {
        this.isPaused = false;
        $('#btn-pause-migration').html('<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-pause" style="margin-right: 8px;"><rect width="4" height="16" x="6" y="4" rx="1"/><rect width="4" height="16" x="14" y="4" rx="1"/></svg> Pause Migration');
        $('#btn-pause-migration').removeClass('ps-opacity-50').prop('disabled', false);
        $('#finish-later-area').css('visibility', 'hidden');

        if (this.pendingNextBatch) {
            var payload = this.pendingNextBatch;
            this.pendingNextBatch = null;
            this.runBatch(payload);
        }
    },

    finishLater: function () {
        window.location.href = controller_url;
    },
};

$(document).ready(function () {
    if (typeof controller_url === 'undefined') return;
    PrestaShift.init();
});
